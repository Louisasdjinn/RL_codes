#import d2lzh as d2l
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
#from mxnet import autograd, gluon, init, nd
#from mxnet.gluon import data as gdata, loss as gloss, nn
import torch.utils.data as Data
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
train_data = pd.read_csv('./House/train.csv')
test_data = pd.read_csv('./House/test.csv')

train_data.shape
test_data.shape

#pre-process the data
all_features = pd.concat((train_data.iloc[:, 1:-1], test_data.iloc[:, 1:]))#concat all the figures

numeric_features = all_features.dtypes[all_features.dtypes != 'object'].index#dtypes returns the data types
all_features[numeric_features] = all_features[numeric_features].apply(lambda x: (x - x.mean()) / (x.std()))

all_features[numeric_features] = all_features[numeric_features].fillna(0)

#decompose discrete characteristics
all_features = pd.get_dummies(all_features, dummy_na=True)
#all_features.shape

n_train = train_data.shape[0]
train_features = np.array(all_features[:n_train].values)
test_features = np.array(all_features[n_train:].values)
train_labels = np.array(train_data.SalePrice.values).reshape((-1, 1))



#training 
def get_net():
    net = nn.Sequential()
    net.add(nn.Dense(1))
    net.initialize()
    return net

class Net(nn.Module):
    def __init__(self,n_feature, n_hidden, n_output):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(n_feature,n_hidden)
        self.fc2 = nn.Linear(n_hidden, n_output)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.fc2(x)
        return x

train_net = Net(n_feature=331, n_hidden=256, n_output=1)     # define the network
print(train_net)  # net architecture

optimizer = torch.optim.Adam(train_net.parameters(), betas=(0.9, 0.999), eps=1e-08)
loss_func = torch.nn.MSELoss()  # this is for regression mean squared loss

def train(net, train_features, train_labels, test_features, test_labels, num_epochs, learning_rate, weight_decay, batch_size):
    train_features = torch.from_numpy(train_features).float()
    train_labels = torch.from_numpy(train_labels).float()
    if test_labels is not None:
        test_features = torch.from_numpy(test_features).float()
        test_labels = torch.from_numpy(test_labels).float()
    train_ls, test_ls = [], []
    data_set = Data.TensorDataset(train_features, train_labels)
    train_iter = Data.DataLoader(data_set, batch_size, shuffle=True)
    for epoch in range(num_epochs):
        for X,y in train_iter:
            da= y
            od=net(X)
            l = loss_func(net(X), y)

            optimizer.zero_grad()   # clear gradients for next train
            l.backward() # backpropagation, compute gradients
            optimizer.step() # apply gradients
        train_ls.append(log_rmse(net, train_features, train_labels))
        if test_labels is not None:
            test_ls.append(log_rmse(net, test_features, test_labels))
    return train_ls, test_ls




def log_rmse(net, features, labels):
    # 将小于1的值设成1，使得取对数时数值更稳定
    net_outputs = net(features)
    clipped_preds = torch.clamp(net_outputs, min=1)#clip to restrain the min and max
    rmse = torch.sqrt(2 * loss_func(clipped_preds.log(), labels.log()).mean())
    return rmse.item()

'''
def train(net, train_features, train_labels, test_features, test_labels,
          num_epochs, learning_rate, batch_size):
    train_ls, test_ls = [], []
    train_iter = gdata.DataLoader(gdata.ArrayDataset(train_features, train_labels), batch_size, shuffle=True)#gadata todo
    # 这里使用了Adam优化算法
    trainer = gluon.Trainer(net.collect_params(), 'adam', {'learning_rate': learning_rate, 'wd': weight_decay})
    for epoch in range(num_epochs):
        for X, y in train_iter:
            with autograd.record():
                l = loss(net(X), y)
            l.backward()
            trainer.step(batch_size)
        train_ls.append(log_rmse(net, train_features, train_labels))
        if test_labels is not None:
            test_ls.append(log_rmse(net, test_features, test_labels))
    return train_ls, test_ls
'''
#KNN validation
def get_k_fold_data(k, i, X, y):
    fold_size = X.shape[0] // k
    X_train, y_train = None, None
    for j in range(k):
        idx = slice(j * fold_size, (j + 1) * fold_size)
        X_part, y_part = X[idx, :], y[idx]
        if j == i:
            X_valid, y_valid = X_part, y_part
        elif X_train is None:
            X_train, y_train = X_part, y_part
        else:
            X_train = np.concatenate((X_train, X_part), axis=0)
            y_train = np.concatenate((y_train, y_part), axis=0)
    return X_train, y_train, X_valid, y_valid
def k_fold(k, X_train, y_train, num_epochs, learning_rate, weight_decay, batch_size):
    train_l_sum, valid_l_sum = 0, 0
    for i in range(k):
        data = get_k_fold_data(k, i, X_train, y_train)
        net = train_net
        train_ls, valid_ls = train(net, *data, num_epochs, learning_rate, weight_decay, batch_size)
        dfasd = train_ls[-1]
        train_l_sum += train_ls[-1]
        valid_l_sum += valid_ls[-1]
        if i == 0:
            x_axis = np.arange(1, num_epochs + 1)
            train_ls = np.array(train_ls).reshape(100,1).squeeze(1)
            test_ls = np.array(valid_ls).reshape(100,1).squeeze(1)
            plt.semilogy(x_axis, train_ls, x_axis, test_ls)# add label TODO
            plt.show()
        print('fold %d, train rmse %f, valid rmse %f'% (i, train_ls[-1], valid_ls[-1]))
    return train_l_sum / k, valid_l_sum / k

k, num_epochs, lr, weight_decay, batch_size = 5, 100, 5, 0, 64
train_l, valid_l = k_fold(k, train_features, train_labels, num_epochs, lr, weight_decay, batch_size)
print('%d-fold validation: avg train rmse %f, avg valid rmse %f' % (k, train_l, valid_l))

#prediction
def train_and_pred(train_features, test_features, train_labels, test_data, num_epochs, lr, weight_decay, batch_size):
    net = train_net
    train_ls, _ = train(net, train_features, train_labels, None, None, num_epochs, lr, weight_decay, batch_size)
    
    x_axis = np.arange(1, num_epochs + 1)
    train_ls = np.array(train_ls).reshape(100,1).squeeze(1)
    plt.semilogy(x_axis, train_ls)
    plt.show()

    print('train rmse %f' % train_ls[-1])
    preds = net(torch.from_numpy(test_features).float()).detach().numpy()
    test_data['SalePrice'] = pd.Series(preds.reshape(1, -1)[0])
    submission = pd.concat([test_data['Id'], test_data['SalePrice']], axis=1)
    submission.to_csv('submission.csv', index=False)

train_and_pred(train_features, test_features, train_labels, test_data, num_epochs, lr, weight_decay, batch_size)